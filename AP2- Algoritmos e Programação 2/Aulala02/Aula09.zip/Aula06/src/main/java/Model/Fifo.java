package Model;
import javax.swing.JOptionPane;
public class Fifo {
// Criando o sentinetas

    NoFifo Primeiro = null;
    NoFifo Ultimo = null;

    public void enfileirar(String dado) {
        NoFifo newFila = new NoFifo();
        // atributos de dados
        newFila.dado = dado;
        newFila.prox = null;

        if (Primeiro == null) {
            Primeiro = newFila;
        } else {
            Ultimo.prox = newFila;
        }

        Ultimo = newFila;
    }

    public void desenfileirar() {
        if ( Primeiro == null ) {
            JOptionPane.showMessageDialog(null, "Fila Vazia!");
            return;
        }

        NoFifo temp = Primeiro;
        Primeiro = temp.prox; // O segundo é o primeiro
        temp = null;
    }

    public void imprimir() {
        
         if ( Primeiro == null ) {
            JOptionPane.showMessageDialog(null, "Não há elementos para imprimir!");
            return;
        }
         
        NoFifo aux = Primeiro;
        String saida = "";
        while ( aux != null) {
            saida += aux.dado + " ";
            aux = aux.prox; // percorrer a estrutura
        }
       
        JOptionPane.showMessageDialog(null, saida);
    }
}
