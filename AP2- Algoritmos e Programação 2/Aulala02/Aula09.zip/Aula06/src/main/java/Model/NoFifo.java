package Model;
public class NoFifo {
    public String dado; 
    public NoFifo prox; 
}
