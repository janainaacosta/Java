package Controller;
import Model.Fifo;
import java.util.Random;
public class UsaFifo {
    
    public static void main(String[] args) {
        Fifo fila = new Fifo();
        Random gerar = new Random();
        int x, i = 0; 
        while ( i < 500){
        x = gerar.nextInt(100) + 1;
        System.out.println(x);
        i++;
        }
        System.exit(0);
        
        fila.enfileirar("10"); fila.imprimir();
        fila.enfileirar("20"); fila.imprimir();
        fila.enfileirar("30"); fila.imprimir();
        
        fila.desenfileirar(); fila.imprimir();
        fila.desenfileirar(); fila.imprimir();
        fila.desenfileirar(); fila.imprimir();
        fila.desenfileirar(); fila.imprimir();
     
    }
            
    
}