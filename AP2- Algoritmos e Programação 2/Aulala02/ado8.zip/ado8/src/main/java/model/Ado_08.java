package model;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class Ado_08 {

    private static String[] nomes; // Declarando o array nomes como uma variável de instância

    public static void classificar_pessoa(int tamanho) {
        nomes = new String[tamanho]; // Inicializando o array nomes

        int[] idades = new int[tamanho];

        for (int i = 0; i < tamanho; i++) {
            nomes[i] = JOptionPane.showInputDialog(null, "Digite o nome : ");
            String idadeString = JOptionPane.showInputDialog("Digite a idade de ");
            idades[i] = Integer.parseInt(idadeString);
        }

        bolha(nomes, idades);
    }

    public static int buscarNome(String nome) {
        

        for (int i = 0; i < nomes.length; i++) {
            if (nomes[i].equalsIgnoreCase(nome)) {
                JOptionPane.showMessageDialog(null, "O nome" + nome + " está na posição " + i + " na lista.", "nome Encontrado", JOptionPane.INFORMATION_MESSAGE);
                return i;
            }
        }
        JOptionPane.showMessageDialog(null, "O nome " + nome + " não está na lista.", "nome Não Encontrado", JOptionPane.INFORMATION_MESSAGE);
        return -1;
    }

    public static void bolha(String[] nomes, int[] idades) {
        int n = nomes.length; // Obtém o número de elementos nos arrays
        boolean trocou;
        String tempNome; // Variável temporária para armazenar nomes durante a troca
        int tempIdade; // Variável temporária para armazenar idades durante a troca

        // Loop do algoritmo de ordenação bubble sort
        do {
            trocou = false; // Define a flag de troca como falsa antes de percorrer o array
            for (int i = 0; i < n - 1; i++) {
                // Compara as idades adjacentes e troca se estiverem fora de ordem
                if (idades[i] > idades[i + 1]) {
                    // Troca os nomes
                    tempNome = nomes[i];
                    nomes[i] = nomes[i + 1];
                    nomes[i + 1] = tempNome;

                    // Troca as idades
                    tempIdade = idades[i];
                    idades[i] = idades[i + 1];
                    idades[i + 1] = tempIdade;

                    trocou = true; // Sinaliza que houve uma troca neste passo
                }
            }
        } while (trocou); // Continua o loop enquanto houver trocas a serem feitas

        // Aqui você pode adicionar a chamada para o método exibir() se necessário
        exibir(nomes, idades);
    }

    public static void exibir(String[] nomes, int[] idades) {
        StringBuilder mensagem = new StringBuilder();
        for (int i = 0; i < nomes.length; i++) {
            mensagem.append("Nome: ").append(nomes[i]).append(", Idade: ").append(idades[i]).append("\n");
        }
        JOptionPane.showMessageDialog(null, mensagem.toString());
    }

    public static int buscaSeq(int x) {
        int lista[] = {1, 2, 4, 5, -1, 0};

        for (int i = 0; i < lista.length; i++) {
            if (lista[i] == x) {
                JOptionPane.showMessageDialog(null, "O numero " + x + " está na posição " + i + " na lista.", "Número Encontrado", JOptionPane.INFORMATION_MESSAGE);
                return i; // Retorna a posição do número na lista
            }
        }

        JOptionPane.showMessageDialog(null, "O número " + x + " não está na lista.", "Número Não Encontrado", JOptionPane.INFORMATION_MESSAGE);
        return -1; // Retorna -1 se o número não for encontrado na lista
    }

    public static void main(String[] args) {
        String nome = "";

    }
}
