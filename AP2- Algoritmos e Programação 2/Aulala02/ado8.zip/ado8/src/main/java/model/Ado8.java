/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package model;

/**
 *
 * @author Janaina Costa
 */
public class Ado8 {
    
    
     public static void exibir(int[] X) {
        for (int i = 0; i < X.length; i++) {
            System.out.print(X[i] + " ");
        }
        System.out.println();
    }

    public static void bolha(int[] X) {
        boolean trocou;
        do {
            trocou = false;
            for (int i = 0; i < X.length - 1; i++) {
                if (X[i] > X[i + 1]) {
                    // Troca os elementos se estiverem fora de ordem
                    int temp = X[i];
                    X[i] = X[i + 1];
                    X[i + 1] = temp;
                    trocou = true;
                }
            }
        } while (trocou);
    }

    public static int buscaSeq(int lista [], int x) {
        for (int i = 0; i < lista.length; i++) {
            if (lista[i] == x) {
                return i; 
            }
        }
        return -1; 
    }

    public static void main(String[] args) {
        int lista [] = {1, 2, 4, 5, -1, 0};
        int procurado = 2;

        int resultado = buscaSeq(lista, procurado);

        if (resultado != -1) {
            System.out.println("O elemento " + procurado + " foi encontrado na posição " + resultado + ".");
        } else {
            System.out.println("O elemento " + procurado + " não foi encontrado na lista.");
        }
        
        
          int[] X = {5, 3, 1, 4, 2};

        System.out.print("Lista original: ");
        exibir(X);

        bolha(X);

        System.out.print("Lista ordenada: ");
        exibir(X);
    }
}
