package controller;

import java.util.Scanner;
import javax.swing.JOptionPane;
import model.Ado_08;

/**
 *
 * @author Janaina Costa
 */
public class menu {

    public static void main(String[] args) {

        while (true) {
            String menu = "=-=-=-=- Menu Pilha Estática =-=-=-=-=-";
            menu += "\n1 - Buscar número\n2 - Classificar pessoas\n3 - filtrar nome\n4 - sair";
            String item = JOptionPane.showInputDialog(null, menu);

            switch (item) {

                case "1":
                    String numero = JOptionPane.showInputDialog(null, "informe o numero: ");

                    int Numero = Integer.parseInt(numero);

                    Ado_08 busca_seq = new Ado_08();

                    busca_seq.buscaSeq(Numero);

                    break;

                case "2":
                    String tamanho_lista = JOptionPane.showInputDialog(null, "Digite o tamanho do vetor de nomes: ");
                    int tamanho = Integer.parseInt(tamanho_lista);

                    Ado_08 classificar = new Ado_08();
                    classificar.classificar_pessoa(tamanho);

                    break;

                case "3":
                    //funcao para filtrar nome
                    String nome = JOptionPane.showInputDialog(null, "Digite o nome: ");

                    Ado_08 buscar_nome = new Ado_08();
                    
                    buscar_nome.buscarNome(nome);
                    break;

                case "4":
                    JOptionPane.showInputDialog(null,
                            "Encerrado.");
                    break;

            }
        }
    }
}
